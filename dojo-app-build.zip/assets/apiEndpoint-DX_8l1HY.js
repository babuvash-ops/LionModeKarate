function n(e){return typeof window>"u"||e.startsWith("/")?e:`/${e}`}export{n as getApiUrl};
