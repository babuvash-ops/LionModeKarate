function u(r,a){var o;const e=(((o=r.filter(i=>i.role==="user").pop())==null?void 0:o.content)||"").toLowerCase().trim(),n=(a==null?void 0:a.name)||"Warrior",s=(a==null?void 0:a.belt)||"White Belt";let t="";if(/^(hi|hello|hey|osu|oss|greetings|morning|afternoon|evening)/.test(e)||e==="sensei")t=`**Osu, ${n}!** 🥋

Welcome to the **Lion Mode Karate tatami**. I am your Dojo Sensei AI assistant.

As a **${s}**, your focus is on discipline, foundation, and deliberate execution. Here is how I can guide your training today:

- **Kata Breakdown & Bunkai:** Step-by-step stance geometry and practical application.
- **Kumite Timing & Drills:** Reflex development, distance management (*Ma-ai*), and counter-attacks.
- **Belt Syllabus & Grading:** Specific requirements to earn your next belt stripe.
- **Dojo Timetable & Classes:** Check class schedules and upcoming open mats.

*What aspect of your martial journey shall we sharpen today?*`;else if(/schedule|class|timetable|hours|times|when is|today|session/.test(e))t=`**Osu!** Here is the official **Lion Mode Karate Dojo Schedule**:

| Program | Days | Time Slot | Focus |
| :--- | :--- | :--- | :--- |
| **Kids & Fundamentals** | Mon / Wed / Fri | 4:00 PM – 5:00 PM | Basics, Balance, Discipline |
| **Advanced Kata & Kumite** | Tue / Thu | 5:30 PM – 7:00 PM | Competition Kata, Sparring Tactics |
| **Adult All-Levels** | Mon / Wed / Sat | 6:30 PM – 8:00 PM | Striking Power, Self-Defense |
| **Open Mat & Testing** | Saturday | 10:00 AM – 12:30 PM | Sparring Rounds, Belt Exams |

> **Sensei Etiquette Note:** Always arrive 10–15 minutes early to bow onto the tatami (*Rei*), stretch your hamstrings, and center your breathing (*Mokuso*).`;else if(/kata|heian|bunkai|taikyoku|bassai|kanku|tekki|form/.test(e)){let i="Heian Shodan";/nidan/.test(e)?i="Heian Nidan":/sandan/.test(e)?i="Heian Sandan":/yondan/.test(e)?i="Heian Yondan":/godan/.test(e)?i="Heian Godan":/tekki/.test(e)?i="Tekki Shodan":/bassai/.test(e)?i="Bassai Dai":/kanku/.test(e)&&(i="Kanku Dai"),t=`**Osu! Detailed Breakdown: ${i}** 🥋

Kata is the encyclopedia of martial arts. Every movement is a deliberate defense and counter-strike.

### 1. Stance Geometry & Preparation
- **Rooted Stance:** Lock your rear leg with heel pressed firmly to the tatami. Front knee bent directly over your ankle.
- **Hip Action (*Koshi*):** Drive your blocks with half-facing hips (*Hanmi*) and finish your punches with square hips (*Shomen*).

### 2. Execution & Repetitions
- **Rhythm:** Do not rush through transitions. Fast movements require sharp snap (*Kime*); slow movements require deep breathing (*Ibuki*).
- **Drill:** Perform the first 6 counts of ${i} at 50% speed for 10 sets, then 5 sets at 100% full speed with sharp *Kiai*.

### 3. Key Sensei Cue
> *"Power does not come from your shoulders—it travels from the tatami through your hips into your fists."*

### 4. Common Flaw to Avoid
- Bobbing your head up and down when stepping forward. Keep your center of gravity level throughout the entire sequence.`}else/sparring|kumite|fight|counter|punch|jab|reverse|speed|timing|reflex/.test(e)?t=`**Osu! Kumite Combat Protocol: Distance & Timing (*Ma-ai*)** 🥊

In sparring, the fighter who controls the space controls the match.

### The "Slip & Counter" Drill (*Sen-no-sen*)

1. **Stance & Footwork:**
   - Bounce lightly on the balls of your feet in fighting stance (*Kamae*).
   - Keep your guard tight with rear hand protecting your jawline and lead hand active.

2. **The 3-Beat Combination:**
   - **Beat 1 (Draw):** Half-step back to slip the opponent's lead attack by 2 inches.
   - **Beat 2 (Explosion):** Fire a lunging reverse punch (*Gyaku-tsuki*) directly into the solar plexus with sharp *Kiai*.
   - **Beat 3 (Exit):** Pivot 45° off-angle to avoid counter-hooks while keeping eyes fixed on the opponent (*Zanshin*).

3. **Training Prescription:**
   - 4 rounds of 3 minutes shadow sparring focusing purely on foot speed and breath control.
   - Rest 45 seconds between rounds with deep diaphragmatic recovery.`:/kick|geri|mawashi|yoko|mae geri|flexibility|stretch|high kick/.test(e)?t=`**Osu! Kicking Mechanics & Hip Chambering** 🦵

A powerful kick is 90% chamber and 10% extension. If the knee does not chamber high and tight, the kick lacks speed and snap.

### Key Drills for High, Snapping Kicks:

1. **Front Snap Kick (*Mae-Geri Keage*):**
   - Lift the knee chest-high with toes pulled back tightly (*Koshi* strike).
   - Snap out and instantly snap back before setting the foot down. Never let the leg drop lazily.

2. **Roundhouse Kick (*Mawashi-Geri*):**
   - Pivot your supporting foot 180° away from the target to open the hip joint.
   - Turn your striking hip fully over so your knee and laces point horizontally, not upward.

3. **Wall Balance Conditioning:**
   - Place one hand on the wall, chamber your roundhouse kick, and hold for 15 seconds. Pulse 10 short extensions without lowering the knee. Repeat 3 sets per leg.`:/belt|grading|exam|rank|stripe|promotion|test|criteria/.test(e)?t=`**Osu! Belt Promotion Standards & Requirements** 🥋

At Lion Mode Karate, belt promotions are earned through discipline, consistent attendance, and technical precision—never given away.

### Core Grading Pillars:

- **1. Kihon (Basics - 30%):** Clean execution of stances, blocks, punches, and kicks with zero balance wobbles.
- **2. Kata (Form - 35%):** Knowing your prescribed belt kata with dynamic rhythm, sharp *Kime*, and solid stances.
- **3. Kumite (Sparring - 20%):** Controlled sparring demonstrating ring awareness, sportsmanship, and quick counter-timing.
- **4. Attendance & Spirit (15%):** Minimum required classes logged on your Dojo Passport and active dojo respect.

*Sensei Advice:* If you are preparing for your upcoming belt examination, ensure your dojo passport attendance streak is current and review your kata daily!`:/gear|uniform|gi|shop|gloves|shin|mouthguard|buy|cost/.test(e)?t=`**Osu! Dojo Gear & Equipment Guidelines** 🥋

Proper safety equipment protects you and your training partners:

- **Standard Training Uniform (*Karate Gi*):** Durable white cotton canvas with official Lion Mode embroidery.
- **Sparring Protection:** Mandatory WKF-approved fist guards (red or blue), mouthguard, and shin/instep guards.
- **Pro Shop:** All authentic Lion Mode gear, training weapons, and academy uniforms can be ordered directly through our **[Pro Shop](#/shop)**.

*Check with Sensei Babu during class if you need sizing assistance for uniforms or sparring pads!*`:t=`**Osu, ${n}!** 🥋

Thank you for your question. As your Sensei, I remind you that true mastery in karate is built one deliberate repetition at a time.

> *"Karate begins and ends with respect (Rei). It is not about defeating others, but conquering your own limitations."*

Here is your recommended training focus for today:

1. **Focus on Stance Depth:** Sink 2 inches lower into your stances to engage your quads and core.
2. **Breath Control (*Kiai*):** Exhale sharply with abdominal contraction on the impact of every technique.
3. **Consistent Practice:** Spend 15 minutes reviewing your belt kata and practicing 50 reverse punches.

Feel free to ask me for specific kata steps, sparring drills, the dojo timetable, or belt grading requirements!`;return{content:t,modelUsed:"Sensei Intelligence Core"}}export{u as generateSenseiResponse};
